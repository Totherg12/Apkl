package dev.n1k.faceoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class FaceOverlay(
    private val context: Context,
    private val screenWidth: Int,
    private val screenHeight: Int
) {
    data class Box(val left: Float, val top: Float, val right: Float, val bottom: Float)

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val view = MarkerView(context)
    private var attached = false

    fun show() {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            screenWidth,
            screenHeight,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager.addView(view, params)
        attached = true
    }

    fun update(boxes: List<Box>) {
        view.boxes = boxes
        view.postInvalidate()
    }

    fun remove() {
        if (attached) {
            windowManager.removeView(view)
            attached = false
        }
    }

    private class MarkerView(context: Context) : View(context) {
        @Volatile var boxes: List<Box> = emptyList()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GREEN
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.YELLOW
            style = Paint.Style.FILL
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            boxes.forEach { box ->
                canvas.drawRoundRect(
                    RectF(box.left, box.top, box.right, box.bottom),
                    8f, 8f, paint
                )
                // Marcador apenas visual no centro superior da caixa detectada.
                canvas.drawCircle((box.left + box.right) / 2f, box.top, 7f, markerPaint)
            }
        }
    }
}
