package dev.n1k.faceoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "N1K Face Overlay\\nDetector visual experimental"
            textSize = 20f
            setPadding(24, 28, 24, 12)
        }
        val info = TextView(this).apply {
            text = "Analisa frames da tela e desenha marcadores sobre rostos detectados. " +
                "Não controla o toque, a câmera ou a mira do jogo. A detecção em jogos pode falhar."
            textSize = 14f
            setPadding(24, 8, 24, 24)
        }
        val start = Button(this).apply {
            text = "Iniciar captura"
            setOnClickListener { beginCapture() }
        }
        val stop = Button(this).apply {
            text = "Parar captura"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            addView(title)
            addView(info)
            addView(start)
            addView(stop)
        })
    }

    private fun beginCapture() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        }
    }
}
