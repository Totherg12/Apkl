plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.n1k.faceoverlay"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.n1k.faceoverlay"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("com.google.mlkit:face-detection:16.1.7")
}
